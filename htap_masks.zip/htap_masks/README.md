Directory containing HTAP masks as NetCDF files
